<?php
function parity($arr){
    $result='';
    
    if (count($arr)<3) {
        $result='elemen array kurang dari 3';
    }else{
     for ($i=0; $i < count($arr); $i++) { 
         if(){
             
         }
     }   
    }

    return $result;
}
$arrNum=array(2, 4, 0, 100, 4, 11, 2602, 36]);
echo parity($arrNum);