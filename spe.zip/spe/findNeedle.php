<?php
function findNeedle($arr, $value){
    $result=null;

    for ($i=0; $i < count($arr); $i++) { 
        if ($arr[$i]==$value) {
            $result=$i;
        }
    }
    return $result;
}

$arrColor=array('red', 'blue', 'yellow', 'black', 'grey');

echo findNeedle($arrColor,'yellow');