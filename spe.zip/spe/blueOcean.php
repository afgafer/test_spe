<?php
function blueOcean($arr, $value){
    unset($value, $arr);
    return $arr;
}

$arrNum=array(1,5,5,5,5,3);
var_dump(blueOcean(5,$arrNum));