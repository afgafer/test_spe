<?php
function nacissistic($value){
    $result=false;
    $sum=0;
    $length=strlen($value);

    for ($i=0; $i < $length; $i++) { 
        $num=substr($value,$i,1);
        $sum+=$num^$length;
    }

    if ($sum==$value) {
        $result=true;
    }
    return $result;
}

echo nacissistic(1634);